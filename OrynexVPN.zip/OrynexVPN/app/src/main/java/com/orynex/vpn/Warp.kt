package com.orynex.vpn

import com.wireguard.crypto.KeyPair
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Registers a free Cloudflare WARP device and returns a ready WireGuard server entry. */
object Warp {
    fun provision(): JSONObject {
        val kp = KeyPair()
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        val body = JSONObject()
            .put("key", kp.publicKey.toBase64())
            .put("install_id", "").put("fcm_token", "")
            .put("tos", fmt.format(Date()))
            .put("model", "Android").put("serial_number", "").put("locale", "en_US")

        val c = URL("https://api.cloudflareclient.com/v0a2158/reg").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("User-Agent", "okhttp/3.12.1")
        c.setRequestProperty("CF-Client-Version", "a-6.3-1922")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) throw Exception("Cloudflare returned ${c.responseCode}")
        val res = JSONObject(c.inputStream.bufferedReader().readText())

        val cfg = res.getJSONObject("config")
        val peer = cfg.getJSONArray("peers").getJSONObject(0)
        val addr = cfg.getJSONObject("interface").getJSONObject("addresses")
        val conf = """
            [Interface]
            PrivateKey = ${kp.privateKey.toBase64()}
            Address = ${addr.getString("v4")}/32, ${addr.getString("v6")}/128
            DNS = 1.1.1.1, 1.0.0.1
            MTU = 1280

            [Peer]
            PublicKey = ${peer.getString("public_key")}
            AllowedIPs = 0.0.0.0/0, ::/0
            Endpoint = engage.cloudflareclient.com:2408
        """.trimIndent()

        return JSONObject()
            .put("id", "warp" + System.currentTimeMillis())
            .put("name", "Cloudflare WARP")
            .put("country", "Auto")
            .put("protocol", "wireguard")
            .put("config", conf)
    }
}
