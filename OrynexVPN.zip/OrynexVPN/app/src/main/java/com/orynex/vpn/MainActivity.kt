package com.orynex.vpn

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val io = Executors.newSingleThreadExecutor()
    private val net = Executors.newCachedThreadPool()
    private var backend: GoBackend? = null
    private var pendingId: String? = null
    private val engine: VpnEngine = Engines.create()
    private var gate: List<GateServer> = emptyList()
    private var active = ""            // "wg" | "ovpn" | ""
    @Volatile private var connected = false

    private val tunnel = object : Tunnel {
        override fun getName() = "orynex"
        override fun onStateChange(newState: Tunnel.State) {
            if (active == "wg") connected = newState == Tunnel.State.UP
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.overScrollMode = WebView.OVER_SCROLL_NEVER
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
        engine.setListener { st, msg ->
            if (active == "ovpn") {
                connected = st == "connected"
                emit(st, msg)
            }
        }
    }

    override fun onDestroy() {
        engine.setListener(null)
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.onBack && window.onBack()") { r ->
            if (r != "true") finish()
        }
    }

    private fun prefs() = getSharedPreferences("orynex", MODE_PRIVATE)

    private fun emit(state: String, msg: String = "") {
        runOnUiThread {
            web.evaluateJavascript(
                "window.onVpnState(${JSONObject.quote(state)},${JSONObject.quote(msg)})", null
            )
        }
    }

    private fun startTunnel(id: String) {
        io.execute {
            try {
                val servers = JSONObject(prefs().getString("data", "{}") ?: "{}")
                    .optJSONArray("servers") ?: JSONArray()
                var cfgText: String? = null
                for (i in 0 until servers.length()) {
                    val s = servers.getJSONObject(i)
                    if (s.getString("id") == id) cfgText = s.getString("config")
                }
                if (cfgText == null) { emit("error", "Server not found"); return@execute }
                active = "wg"
                emit("connecting")
                val cfg = Config.parse(ByteArrayInputStream(cfgText.toByteArray()))
                if (backend == null) backend = GoBackend(applicationContext)
                backend!!.setState(tunnel, Tunnel.State.UP, cfg)
                connected = true
                emit("connected")
            } catch (e: Exception) {
                emit("error", e.message ?: "Connection failed")
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100) {
            val id = pendingId
            if (resultCode == RESULT_OK && id != null) startTunnel(id)
            else emit("error", "VPN permission denied")
            pendingId = null
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun load(): String = prefs().getString("data", "{\"servers\":[],\"selected\":\"\"}")!!

        @JavascriptInterface
        fun save(json: String) { prefs().edit().putString("data", json).apply() }

        @JavascriptInterface
        fun isConnected(): Boolean = connected

        @JavascriptInterface
        fun hasEngine(): Boolean = engine.available

        @JavascriptInterface
        fun fetchGate() {
            net.execute {
                val r = try {
                    gate = VpnGate.fetch()
                    JSONObject().put("ok", true).put("countries", VpnGate.countriesJson(gate))
                } catch (e: Exception) {
                    JSONObject().put("ok", false).put("error", e.message ?: "Network error")
                }
                runOnUiThread { web.evaluateJavascript("window.onGate($r)", null) }
            }
        }

        @JavascriptInterface
        fun connectOvpn(index: Int) {
            runOnUiThread {
                val g = gate.getOrNull(index)
                if (g == null) { emit("error", "Server list expired, refresh"); return@runOnUiThread }
                if (!engine.available) { emit("error", "OpenVPN engine not included in this build"); return@runOnUiThread }
                active = "ovpn"
                emit("connecting")
                engine.start(this@MainActivity, g.config, g.country + " " + g.ip)
            }
        }

        @JavascriptInterface
        fun connect(id: String) {
            runOnUiThread {
                val intent = VpnService.prepare(this@MainActivity)
                if (intent != null) {
                    pendingId = id
                    startActivityForResult(intent, 100)
                } else startTunnel(id)
            }
        }

        @JavascriptInterface
        fun addWarp() {
            net.execute {
                val r = try {
                    JSONObject().put("ok", true).put("server", Warp.provision())
                } catch (e: Exception) {
                    JSONObject().put("ok", false).put("error", e.message ?: "Network error")
                }
                runOnUiThread { web.evaluateJavascript("window.onWarp($r)", null) }
            }
        }

        @JavascriptInterface
        fun disconnect() {
            if (active == "ovpn") {
                runOnUiThread { engine.stop(this@MainActivity) }
                connected = false
                emit("disconnected")
                return
            }
            io.execute {
                try {
                    backend?.setState(tunnel, Tunnel.State.DOWN, null)
                    connected = false
                    emit("disconnected")
                } catch (e: Exception) {
                    emit("error", e.message ?: "Disconnect failed")
                }
            }
        }
    }
}
