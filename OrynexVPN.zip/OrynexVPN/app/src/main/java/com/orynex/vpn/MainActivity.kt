package com.orynex.vpn

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private val io = Executors.newSingleThreadExecutor()
    private var backend: GoBackend? = null
    private var pendingId: String? = null
    @Volatile private var connected = false

    private val tunnel = object : Tunnel {
        override fun getName() = "orynex"
        override fun onStateChange(newState: Tunnel.State) {
            connected = newState == Tunnel.State.UP
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.overScrollMode = WebView.OVER_SCROLL_NEVER
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.onBack && window.onBack()") { r ->
            if (r != "true") finish()
        }
    }

    private fun prefs() = getSharedPreferences("orynex", MODE_PRIVATE)

    private fun emit(state: String, msg: String = "") {
        runOnUiThread {
            web.evaluateJavascript(
                "window.onVpnState(${JSONObject.quote(state)},${JSONObject.quote(msg)})", null
            )
        }
    }

    private fun startTunnel(id: String) {
        io.execute {
            try {
                val servers = JSONObject(prefs().getString("data", "{}") ?: "{}")
                    .optJSONArray("servers") ?: JSONArray()
                var cfgText: String? = null
                for (i in 0 until servers.length()) {
                    val s = servers.getJSONObject(i)
                    if (s.getString("id") == id) cfgText = s.getString("config")
                }
                if (cfgText == null) { emit("error", "Server not found"); return@execute }
                emit("connecting")
                val cfg = Config.parse(ByteArrayInputStream(cfgText.toByteArray()))
                if (backend == null) backend = GoBackend(applicationContext)
                backend!!.setState(tunnel, Tunnel.State.UP, cfg)
                emit("connected")
            } catch (e: Exception) {
                emit("error", e.message ?: "Connection failed")
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100) {
            val id = pendingId
            if (resultCode == RESULT_OK && id != null) startTunnel(id)
            else emit("error", "VPN permission denied")
            pendingId = null
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun load(): String = prefs().getString("data", "{\"servers\":[],\"selected\":\"\"}")!!

        @JavascriptInterface
        fun save(json: String) { prefs().edit().putString("data", json).apply() }

        @JavascriptInterface
        fun addWarp() {
            io.execute {
                val r = try {
                    JSONObject().put("ok", true).put("server", Warp.provision())
                } catch (e: Exception) {
                    JSONObject().put("ok", false).put("error", e.message ?: "Network error")
                }
                runOnUiThread { web.evaluateJavascript("window.onWarp($r)", null) }
            }
        }

        @JavascriptInterface
        fun isConnected(): Boolean = connected

        @JavascriptInterface
        fun connect(id: String) {
            runOnUiThread {
                val intent = VpnService.prepare(this@MainActivity)
                if (intent != null) {
                    pendingId = id
                    startActivityForResult(intent, 100)
                } else startTunnel(id)
            }
        }

        @JavascriptInterface
        fun disconnect() {
            io.execute {
                try {
                    backend?.setState(tunnel, Tunnel.State.DOWN, null)
                    emit("disconnected")
                } catch (e: Exception) {
                    emit("error", e.message ?: "Disconnect failed")
                }
            }
        }
    }
}
