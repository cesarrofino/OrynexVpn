package com.orynex.vpn

import android.app.Activity

/** OpenVPN engine abstraction. state: connecting | connected | disconnected | error */
interface VpnEngine {
    val available: Boolean
    fun setListener(l: ((state: String, msg: String) -> Unit)?)
    fun start(activity: Activity, config: String, name: String)
    fun stop(activity: Activity)
}
