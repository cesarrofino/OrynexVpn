package com.orynex.vpn

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class GateServer(
    val country: String, val code: String, val ip: String,
    val ping: Int, val score: Long, val config: String
)

/** Public server list from VPN Gate (University of Tsukuba). */
object VpnGate {
    fun fetch(): List<GateServer> {
        val c = URL("https://www.vpngate.net/api/iphone/").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 40000
        if (c.responseCode !in 200..299) throw Exception("VPN Gate returned ${c.responseCode}")
        val text = c.inputStream.bufferedReader().readText()
        val out = ArrayList<GateServer>()
        for (line in text.lineSequence()) {
            if (line.isBlank() || line.startsWith("*") || line.startsWith("#")) continue
            val f = line.split(",")
            if (f.size < 15) continue
            val cfg = try { String(Base64.decode(f.last().trim(), Base64.DEFAULT)) } catch (e: Exception) { continue }
            if (!cfg.contains("remote ")) continue
            // Operator profiles in Orynex use real public UDP relays only.
            // Never rewrite a relay's port: the server must listen on its published endpoint.
            if (!Regex("(?im)^\\s*proto\\s+udp[46]?\\s*$").containsMatchIn(cfg)) continue
            out.add(
                GateServer(
                    country = f[5], code = f[6].uppercase(), ip = f[1],
                    ping = f[3].toIntOrNull() ?: 9999,
                    score = f[2].toLongOrNull() ?: 0L, config = cfg
                )
            )
        }
        if (out.isEmpty()) throw Exception("Empty server list")
        return out
    }

    /** Countries with the indexes (into [list]) of their 5 best servers. */
    fun countriesJson(list: List<GateServer>): JSONArray {
        val arr = JSONArray()
        val groups = list.withIndex().groupBy { it.value.code }
        groups.entries.sortedByDescending { it.value.size }.forEach { (code, items) ->
            val top = items.sortedByDescending { it.value.score }.take(5)
            val o = JSONObject()
            o.put("code", code)
            o.put("name", items.first().value.country)
            o.put("count", items.size)
            o.put("ping", top.minOf { it.value.ping })
            o.put("ids", JSONArray(top.map { it.index }))
            arr.put(o)
        }
        return arr
    }
}
