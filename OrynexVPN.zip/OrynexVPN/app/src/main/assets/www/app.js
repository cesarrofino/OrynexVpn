(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var native = window.Android || null;
  var data = { servers: [], selected: '', selCountry: null };
  var gate = { countries: [], loaded: false, loading: false };
  var status = 'disconnected', startTs = 0, tick = null, current = 'home', tab = 'countries';
  var operatorProfile = null;
  var attempt = { code: '', i: 0 }, connTimer = null, warping = false;

  function load() {
    try {
      var raw = native ? native.load() : localStorage.getItem('orynex') || '{}';
      var d = JSON.parse(raw);
      data.servers = d.servers || [];
      data.selected = d.selected || '';
      data.selCountry = d.selCountry || null;
    } catch (e) {}
  }
  function save() {
    var s = JSON.stringify(data);
    if (native) native.save(s); else localStorage.setItem('orynex', s);
  }
  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.remove('show'); }, 2800);
  }
  function flag(code) {
    if (!code || code.length !== 2) return '🌐';
    return String.fromCodePoint(0x1F1E6 + code.charCodeAt(0) - 65, 0x1F1E6 + code.charCodeAt(1) - 65);
  }
  function selected() {
    if (data.selected.indexOf('country:') === 0 && data.selCountry)
      return { kind: 'country', code: data.selCountry.code, name: data.selCountry.name };
    for (var i = 0; i < data.servers.length; i++)
      if (data.servers[i].id === data.selected) { var s = data.servers[i]; s.kind = 'custom'; return s; }
    return null;
  }
  function show(view) {
    current = view;
    ['home', 'servers', 'form'].forEach(function (v) { $(v).classList.toggle('active', v === view); });
    document.querySelectorAll('.tabs button').forEach(function (b) {
      b.classList.toggle('on', b.dataset.go === (view === 'form' ? 'servers' : view));
    });
    if (view === 'servers' && !gate.loaded && !gate.loading) fetchGate();
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmt(ms) {
    var s = Math.floor(ms / 1000);
    return pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s / 60) % 60) + ':' + pad(s % 60);
  }

  function renderHome() {
    var s = selected();
    $('srvName').textContent = s ? (s.kind === 'country' ? flag(s.code) + ' ' + s.name : s.name) : 'Choose a location';
    $('srvSub').textContent = s ? (s.kind === 'country' ? 'OpenVPN · best available server' : (s.country || 'WireGuard') + ' · ' + s.protocol) : 'Tap to pick a country';
    var labels = { disconnected: 'Disconnected', connecting: 'Connecting…', connected: 'Connected' };
    $('statusText').textContent = labels[status] || 'Disconnected';
    $('statusText').classList.toggle('on', status === 'connected');
    $('power').className = 'power ' + (status === 'disconnected' ? '' : status);
  }

  function renderCountries() {
    var box = $('countryList'); box.innerHTML = '';
    var msg = $('gateMsg');
    if (gate.loading) msg.textContent = 'Loading public servers…';
    else if (!gate.loaded) msg.textContent = gate.err ? 'Could not load: ' + gate.err : '';
    else if (native && !native.hasEngine()) msg.textContent = 'This build has no OpenVPN engine, so countries cannot connect. Use “My servers”.';
    else msg.textContent = 'Public servers from VPN Gate. Speed and privacy vary.';
    // Requested destinations are pinned at the top. VPN Gate reports country, not city;
    // Paris and Amsterdam therefore use France/Netherlands relays and are labelled honestly.
    var preferred = [
      { code: 'CA', label: 'Canada' },
      { code: 'BR', label: 'Brazil' },
      { code: 'US', label: 'United States' },
      { code: 'FR', label: 'Paris · France', cityAlias: true },
      { code: 'NL', label: 'Amsterdam · Netherlands', cityAlias: true }
    ];
    var byCode = {};
    gate.countries.forEach(function (c) { byCode[c.code] = c; });
    var shown = [];
    preferred.forEach(function (p) {
      var c = byCode[p.code];
      shown.push({
        code: p.code, name: p.label, count: c ? c.count : 0,
        ping: c ? c.ping : 9999, ids: c ? c.ids : [],
        cityAlias: !!p.cityAlias, unavailable: !c || !c.ids || !c.ids.length
      });
    });
    gate.countries.filter(function (c) {
      return !preferred.some(function (p) { return p.code === c.code; });
    }).forEach(function (c) { shown.push(c); });

    shown.forEach(function (c) {
      var el = document.createElement('div');
      el.className = 'glass item' + (data.selected === 'country:' + c.code ? ' sel' : '') + (c.unavailable ? ' unavailable' : '');
      var f = document.createElement('div'); f.className = 'flag'; f.innerHTML = '<span class="emoji"></span>';
      f.firstChild.textContent = flag(c.code);
      var meta = document.createElement('div'); meta.className = 'meta';
      var n = document.createElement('strong'); n.textContent = c.name;
      var sm = document.createElement('small');
      sm.textContent = c.unavailable ? 'No public server currently available' : (c.count + (c.count === 1 ? ' server' : ' servers') + (c.cityAlias ? ' · city not verified by provider' : ''));
      meta.appendChild(n); meta.appendChild(sm);
      var p = document.createElement('span'); p.className = 'ping'; p.textContent = !c.unavailable && c.ping < 9999 ? c.ping + ' ms' : '';
      el.appendChild(f); el.appendChild(meta); el.appendChild(p);
      el.onclick = function () {
        if (c.unavailable) return toast('No active VPN Gate server for this location. Refresh later.');
        if (status !== 'disconnected') return toast('Disconnect first');
        data.selected = 'country:' + c.code; data.selCountry = { code: c.code, name: c.name };
        save(); renderCountries(); renderHome(); show('home');
      };
      box.appendChild(el);
    });
  }

  function renderList() {
    var box = $('list'); box.innerHTML = '';
    if (!data.servers.length) {
      box.innerHTML = '<p class="empty">No servers yet. Tap “Free server” or paste a WireGuard configuration with “Add”.</p>';
      return;
    }
    data.servers.forEach(function (s) {
      var el = document.createElement('div');
      el.className = 'glass item' + (s.id === data.selected ? ' sel' : '');
      var fl = document.createElement('div'); fl.className = 'flag';
      fl.textContent = (s.country || s.name || '?').slice(0, 2).toUpperCase();
      var meta = document.createElement('div'); meta.className = 'meta';
      var n = document.createElement('strong'); n.textContent = s.name;
      var c = document.createElement('small'); c.textContent = (s.country || '—') + ' · ' + s.protocol;
      meta.appendChild(n); meta.appendChild(c);
      var del = document.createElement('button'); del.className = 'del'; del.textContent = 'Delete';
      del.onclick = function (e) {
        e.stopPropagation();
        if (status !== 'disconnected' && s.id === data.selected) return toast('Disconnect first');
        data.servers = data.servers.filter(function (x) { return x.id !== s.id; });
        if (data.selected === s.id) data.selected = '';
        save(); renderList(); renderHome();
      };
      el.onclick = function () {
        if (status !== 'disconnected') return toast('Disconnect first');
        data.selected = s.id; save(); renderList(); renderCountries(); renderHome(); show('home');
      };
      el.appendChild(fl); el.appendChild(meta); el.appendChild(del);
      box.appendChild(el);
    });
  }

  function setTab(t) {
    tab = t;
    document.querySelectorAll('.seg button').forEach(function (b) { b.classList.toggle('on', b.dataset.tab === t); });
    $('countriesWrap').style.display = t === 'countries' ? '' : 'none';
    $('operatorsWrap').style.display = t === 'operators' ? '' : 'none';
    $('mineWrap').style.display = t === 'mine' ? '' : 'none';
    if (t === 'operators') renderOperators();
  }

  function setStatus(s) {
    var was = status;
    status = s;
    clearInterval(tick);
    if (s !== 'connecting') { clearTimeout(connTimer); }
    if (s === 'connected') {
      attempt.code = '';
      if (was !== 'connected') startTs = Date.now();
      tick = setInterval(function () { $('timer').textContent = fmt(Date.now() - startTs); }, 1000);
    } else if (s === 'disconnected') $('timer').textContent = '00:00:00';
    renderHome();
  }

  // ---- VPN Gate ----
  function fetchGate() {
    if (!native || gate.loading) return;
    gate.loading = true; gate.err = ''; renderCountries();
    native.fetchGate();
  }
  window.onGate = function (r) {
    gate.loading = false;
    if (r.ok) { gate.countries = r.countries; gate.loaded = true; gate.err = ''; }
    else { gate.err = r.error; toast('Could not load countries'); }
    renderCountries(); renderHome();
  };

  // ---- Mozambique operator profile presets ----
  var operators = [
    { id: 'vodacom', name: 'Vodacom Moçambique', icon: '🔴' },
    { id: 'movitel', name: 'Movitel', icon: '🟢' },
    { id: 'tmcel', name: 'Tmcel', icon: '🔵' }
  ];
  function renderOperators() {
    var box = $('operatorList'); if (!box) return; box.innerHTML = '';
    operators.forEach(function (op) {
      var card = document.createElement('div'); card.className = 'glass operator-card';
      var title = document.createElement('h3'); title.textContent = op.icon + ' ' + op.name; card.appendChild(title);
      var desc = document.createElement('p'); desc.className = 'note'; desc.textContent = 'Perfis UDP disponíveis no catálogo'; card.appendChild(desc);
      var ports = document.createElement('div'); ports.className = 'port-grid';
      [48,49,50,51,52,53].forEach(function (port) {
        var b = document.createElement('button'); b.className = 'port-btn'; b.textContent = 'UDP ' + port;
        b.onclick = function () {
          if (status !== 'disconnected') return toast('Desconecta primeiro');
          operatorProfile = { operator: op.name, requestedPort: port };
          connectOperatorProfile();
        };
        ports.appendChild(b);
      });
      card.appendChild(ports); box.appendChild(card);
    });
  }
  function connectOperatorProfile() {
    if (!native) return toast('A conexão VPN requer a aplicação Android instalada.');
    if (gate.loading) return toast('A carregar servidores UDP…');
    if (!gate.loaded) { fetchGate(); return toast('A carregar servidores públicos UDP… tenta novamente em instantes.'); }
    var candidates = [];
    gate.countries.forEach(function (c) { (c.ids || []).forEach(function (id) { candidates.push({id:id, country:c.name, code:c.code}); }); });
    if (!candidates.length) return toast('Nenhum servidor público UDP disponível neste momento.');
    // Pick the first currently published UDP relay; VPN Gate changes its volunteer relays frequently.
    var chosen = candidates[0];
    attempt = { code: chosen.code, i: 0 };
    data.selected = 'country:' + chosen.code; data.selCountry = {code:chosen.code, name:chosen.country}; save();
    renderHome(); setStatus('connecting');
    toast(operatorProfile.operator + ' · perfil UDP ' + operatorProfile.requestedPort + '. A usar a porta real publicada pelo servidor VPN.');
    if (!native.hasEngine()) { setStatus('disconnected'); return toast('Motor OpenVPN não incluído nesta compilação.'); }
    clearTimeout(connTimer); connTimer = setTimeout(function(){ failAttempt('Tempo esgotado ao conectar ao servidor UDP'); }, 35000);
    native.connectOvpn(chosen.id);
  }

  // ---- connect flow ----
  function connectCountry() {
    var c = null;
    for (var i = 0; i < gate.countries.length; i++) if (gate.countries[i].code === attempt.code) c = gate.countries[i];
    if (!c) { setStatus('disconnected'); toast('Load the country list first'); fetchGate(); return; }
    if (!native.hasEngine()) { setStatus('disconnected'); toast('OpenVPN engine not included in this build'); return; }
    clearTimeout(connTimer);
    connTimer = setTimeout(function () { failAttempt('Timed out'); }, 30000);
    native.connectOvpn(c.ids[attempt.i]);
  }
  function failAttempt(msg) {
    var c = null;
    for (var i = 0; i < gate.countries.length; i++) if (gate.countries[i].code === attempt.code) c = gate.countries[i];
    if (c && attempt.i + 1 < Math.min(c.ids.length, 3)) {
      attempt.i++; toast('Trying another server…');
      if (native) native.disconnect();
      setTimeout(connectCountry, 1500);
      return;
    }
    attempt.code = '';
    if (native) native.disconnect();
    setStatus('disconnected'); toast(msg || 'Connection failed');
  }

  window.onVpnState = function (state, msg) {
    if (state === 'error') {
      if (attempt.code) return failAttempt(msg);
      setStatus('disconnected'); return toast(msg || 'Connection failed');
    }
    if (state === 'disconnected' && status === 'connecting' && attempt.code) return; // engine noise while retrying
    setStatus(state);
  };
  window.onBack = function () {
    if (current === 'form') { show('servers'); return true; }
    if (current === 'servers') { show('home'); return true; }
    return false;
  };

  $('power').onclick = function () {
    if (status !== 'disconnected') {
      attempt.code = ''; clearTimeout(connTimer);
      if (native) native.disconnect(); else setStatus('disconnected');
      if (status === 'connecting') setStatus('disconnected');
      return;
    }
    var s = selected();
    if (!s) { show('servers'); return toast('Pick a location first'); }
    setStatus('connecting');
    if (!native) { setStatus('disconnected'); return toast('Instala a versão Android para iniciar uma VPN real.'); }
    if (s.kind === 'country') { attempt = { code: s.code, i: 0 }; connectCountry(); }
    else native.connect(s.id);
  };
  $('serverPick').onclick = function () { show('servers'); };
  $('refreshBtn').onclick = function () { gate.loaded = false; fetchGate(); };
  document.querySelectorAll('.seg button').forEach(function (b) { b.onclick = function () { setTab(b.dataset.tab); }; });

  // ---- my servers ----
  function getWarp() {
    if (!native || warping) return;
    warping = true; toast('Setting up free server…');
    native.addWarp();
  }
  window.onWarp = function (r) {
    warping = false;
    if (!r.ok) return toast('Could not create server: ' + r.error);
    data.servers.push(r.server);
    if (!data.selected) data.selected = r.server.id;
    save(); renderList(); renderHome(); toast('Free server ready');
  };
  $('warpBtn').onclick = getWarp;
  $('addBtn').onclick = function () {
    ['fName', 'fCountry', 'fConf'].forEach(function (i) { $(i).value = ''; });
    $('fErr').textContent = ''; show('form');
  };
  $('fCancel').onclick = function () { show('servers'); setTab('mine'); };
  $('fSave').onclick = function () {
    var name = $('fName').value.trim(), conf = $('fConf').value.trim();
    if (!name) return ($('fErr').textContent = 'Enter a server name.');
    if (conf.indexOf('[Interface]') < 0 || conf.indexOf('[Peer]') < 0)
      return ($('fErr').textContent = 'The configuration needs [Interface] and [Peer] sections.');
    var id = 's' + Date.now();
    data.servers.push({ id: id, name: name, country: $('fCountry').value.trim(), protocol: $('fProto').value, config: conf });
    if (!data.selected) data.selected = id;
    save(); renderList(); renderHome(); show('servers'); setTab('mine'); toast('Server saved');
  };
  document.querySelectorAll('.tabs button').forEach(function (b) {
    b.onclick = function () { show(b.dataset.go); };
  });

  load(); renderList(); renderCountries(); renderHome(); setTab('countries');
  if (native && native.isConnected()) setStatus('connected');
  if (native) fetchGate();
})();
