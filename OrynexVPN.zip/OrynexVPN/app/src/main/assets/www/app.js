(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var native = window.Android || null;
  var data = { servers: [], selected: '' };
  var status = 'disconnected', startTs = 0, tick = null, current = 'home';

  function load() {
    try {
      var raw = native ? native.load() : localStorage.getItem('orynex') || '{}';
      var d = JSON.parse(raw);
      data.servers = d.servers || [];
      data.selected = d.selected || '';
    } catch (e) {}
  }
  function save() {
    var s = JSON.stringify(data);
    if (native) native.save(s); else localStorage.setItem('orynex', s);
  }
  function toast(msg) {
    var t = $('toast'); t.textContent = msg; t.classList.add('show');
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.remove('show'); }, 2600);
  }
  function selected() {
    for (var i = 0; i < data.servers.length; i++) if (data.servers[i].id === data.selected) return data.servers[i];
    return null;
  }
  function show(view) {
    current = view;
    ['home', 'servers', 'form'].forEach(function (v) { $(v).classList.toggle('active', v === view); });
    document.querySelectorAll('.tabs button').forEach(function (b) {
      b.classList.toggle('on', b.dataset.go === (view === 'form' ? 'servers' : view));
    });
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmt(ms) {
    var s = Math.floor(ms / 1000);
    return pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s / 60) % 60) + ':' + pad(s % 60);
  }
  function renderHome() {
    var s = selected();
    $('srvName').textContent = s ? s.name : 'No server';
    $('srvSub').textContent = s ? (s.country || 'WireGuard') + ' · ' + s.protocol : 'Add a server to start';
    var labels = { disconnected: 'Disconnected', connecting: 'Connecting…', connected: 'Connected' };
    $('statusText').textContent = labels[status] || 'Disconnected';
    $('statusText').classList.toggle('on', status === 'connected');
    $('power').className = 'power ' + (status === 'disconnected' ? '' : status);
  }
  function renderList() {
    var box = $('list'); box.innerHTML = '';
    if (!data.servers.length) {
      box.innerHTML = '<p class="empty">No servers yet. Tap “Add server” and paste a WireGuard configuration.</p>';
      return;
    }
    data.servers.forEach(function (s) {
      var el = document.createElement('div');
      el.className = 'glass item' + (s.id === data.selected ? ' sel' : '');
      var flag = document.createElement('div'); flag.className = 'flag';
      flag.textContent = (s.country || s.name || '?').slice(0, 2).toUpperCase();
      var meta = document.createElement('div'); meta.className = 'meta';
      var n = document.createElement('strong'); n.textContent = s.name;
      var c = document.createElement('small'); c.textContent = (s.country || '—') + ' · ' + s.protocol;
      meta.appendChild(n); meta.appendChild(c);
      var del = document.createElement('button'); del.className = 'del'; del.textContent = 'Delete';
      del.onclick = function (e) {
        e.stopPropagation();
        if (status !== 'disconnected' && s.id === data.selected) return toast('Disconnect first');
        data.servers = data.servers.filter(function (x) { return x.id !== s.id; });
        if (data.selected === s.id) data.selected = data.servers[0] ? data.servers[0].id : '';
        save(); renderList(); renderHome();
      };
      el.onclick = function () {
        if (status !== 'disconnected') return toast('Disconnect first');
        data.selected = s.id; save(); renderList(); renderHome(); show('home');
      };
      el.appendChild(flag); el.appendChild(meta); el.appendChild(del);
      box.appendChild(el);
    });
  }
  function setStatus(s) {
    status = s;
    clearInterval(tick);
    if (s === 'connected') {
      startTs = Date.now();
      tick = setInterval(function () { $('timer').textContent = fmt(Date.now() - startTs); }, 1000);
    } else if (s === 'disconnected') $('timer').textContent = '00:00:00';
    renderHome();
  }

  window.onVpnState = function (state, msg) {
    if (state === 'error') { setStatus('disconnected'); toast(msg || 'Connection failed'); }
    else setStatus(state);
  };
  var warping = false;
  function getWarp() {
    if (!native || warping) return;
    warping = true; toast('Setting up free server…');
    native.addWarp();
  }
  window.onWarp = function (r) {
    warping = false;
    if (!r.ok) return toast('Could not create server: ' + r.error);
    data.servers.push(r.server);
    if (!data.selected) data.selected = r.server.id;
    save(); renderList(); renderHome(); toast('Free server ready');
  };
  $('warpBtn').onclick = getWarp;
  window.onBack = function () {
    if (current === 'form') { show('servers'); return true; }
    if (current === 'servers') { show('home'); return true; }
    return false;
  };

  $('power').onclick = function () {
    if (status === 'connecting') return;
    if (status === 'connected') {
      if (native) native.disconnect(); else setStatus('disconnected');
      return;
    }
    var s = selected();
    if (!s) { show('servers'); return toast('Add a server first'); }
    setStatus('connecting');
    if (native) native.connect(s.id);
    else setTimeout(function () { setStatus('connected'); }, 1200);
  };
  $('serverPick').onclick = function () { show('servers'); };
  $('addBtn').onclick = function () {
    ['fName', 'fCountry', 'fConf'].forEach(function (i) { $(i).value = ''; });
    $('fErr').textContent = ''; show('form');
  };
  $('fCancel').onclick = function () { show('servers'); };
  $('fSave').onclick = function () {
    var name = $('fName').value.trim(), conf = $('fConf').value.trim();
    if (!name) return ($('fErr').textContent = 'Enter a server name.');
    if (conf.indexOf('[Interface]') < 0 || conf.indexOf('[Peer]') < 0)
      return ($('fErr').textContent = 'The configuration needs [Interface] and [Peer] sections.');
    var id = 's' + Date.now();
    data.servers.push({ id: id, name: name, country: $('fCountry').value.trim(), protocol: $('fProto').value, config: conf });
    if (!data.selected) data.selected = id;
    save(); renderList(); renderHome(); show('servers'); toast('Server saved');
  };
  document.querySelectorAll('.tabs button').forEach(function (b) {
    b.onclick = function () { show(b.dataset.go); };
  });

  load(); renderList(); renderHome();
  if (native && native.isConnected()) setStatus('connected');
  if (native && !data.servers.length) getWarp();
})();
