package com.orynex.vpn

import android.app.Activity
import android.content.Intent
import de.blinkt.openvpn.LaunchVPN
import de.blinkt.openvpn.activities.DisconnectVPN
import de.blinkt.openvpn.core.ConfigParser
import de.blinkt.openvpn.core.ConnectionStatus
import de.blinkt.openvpn.core.ProfileManager
import de.blinkt.openvpn.core.VpnStatus
import java.io.StringReader

object Engines {
    fun create(): VpnEngine = OvpnEngine()
}

class OvpnEngine : VpnEngine, VpnStatus.StateListener {
    override val available = true
    private var listener: ((String, String) -> Unit)? = null
    private var registered = false

    override fun setListener(l: ((String, String) -> Unit)?) {
        listener = l
        if (l != null && !registered) { VpnStatus.addStateListener(this); registered = true }
        if (l == null && registered) { VpnStatus.removeStateListener(this); registered = false }
    }

    override fun start(activity: Activity, config: String, name: String) {
        try {
            val cp = ConfigParser()
            cp.parseConfig(StringReader(config))
            val vp = cp.convertProfile()
            vp.mName = name
            vp.mUsername = "vpn"      // VPN Gate servers accept vpn/vpn when they ask for credentials
            vp.mPassword = "vpn"
            ProfileManager.setTemporaryProfile(activity, vp)
            val i = Intent(activity, LaunchVPN::class.java)
            i.putExtra(LaunchVPN.EXTRA_KEY, vp.uuid.toString())
            i.action = Intent.ACTION_MAIN
            activity.startActivity(i)
        } catch (e: Exception) {
            listener?.invoke("error", e.message ?: "OpenVPN error")
        }
    }

    override fun stop(activity: Activity) {
        val i = Intent(activity, DisconnectVPN::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(i)
    }

    override fun updateState(
        state: String?, logmessage: String?, localizedResId: Int,
        level: ConnectionStatus?, intent: Intent?
    ) {
        val s = when (level) {
            ConnectionStatus.LEVEL_CONNECTED -> "connected"
            ConnectionStatus.LEVEL_NOTCONNECTED -> "disconnected"
            ConnectionStatus.LEVEL_AUTH_FAILED -> "error"
            else -> "connecting"
        }
        listener?.invoke(s, if (s == "error") (logmessage ?: "Authentication failed") else "")
    }

    override fun setConnectedVPN(uuid: String?) {}
}
