package com.orynex.vpn

import android.app.Activity
import android.content.Intent
import de.blinkt.openvpn.LaunchVPN
import de.blinkt.openvpn.activities.DisconnectVPN
import de.blinkt.openvpn.core.ConfigParser
import de.blinkt.openvpn.core.ConnectionStatus
import de.blinkt.openvpn.core.ProfileManager
import de.blinkt.openvpn.core.VpnStatus
import java.io.StringReader

object Engines {
    fun create(): VpnEngine = OvpnEngine()
}

class OvpnEngine : VpnEngine, VpnStatus.StateListener {
    override val available = true
    private var listener: ((String, String) -> Unit)? = null
    private var registered = false

    override fun setListener(l: ((String, String) -> Unit)?) {
        listener = l
        if (l != null && !registered) { VpnStatus.addStateListener(this); registered = true }
        if (l == null && registered) { VpnStatus.removeStateListener(this); registered = false }
    }

    @Volatile private var launching = false

    override fun start(activity: Activity, config: String, name: String) {
        if (launching) return
        launching = true
        try {
            val cp = ConfigParser()
            cp.parseConfig(StringReader(config))
            val vp = cp.convertProfile()
            vp.mName = name
            // VPN Gate's published profiles commonly request the public vpn/vpn login.
            vp.mUsername = "vpn"
            vp.mPassword = "vpn"
            ProfileManager.setTemporaryProfile(activity, vp)
            val launch = Intent(activity, LaunchVPN::class.java).apply {
                putExtra(LaunchVPN.EXTRA_KEY, vp.uuid.toString())
                action = Intent.ACTION_MAIN
            }
            activity.startActivity(launch)
        } catch (e: Exception) {
            launching = false
            listener?.invoke("error", e.localizedMessage ?: e.javaClass.simpleName)
        } catch (e: LinkageError) {
            launching = false
            listener?.invoke("error", "OpenVPN native engine could not load: ${e.message ?: "missing native library"}")
        }
    }

    override fun stop(activity: Activity) {
        launching = false
        try {
            val i = Intent(activity, DisconnectVPN::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(i)
        } catch (e: Exception) {
            listener?.invoke("error", e.localizedMessage ?: "Could not stop VPN")
        }
    }

    override fun updateState(
        state: String?, logmessage: String?, localizedResId: Int,
        level: ConnectionStatus?, intent: Intent?
    ) {
        val s = when (level) {
            ConnectionStatus.LEVEL_CONNECTED -> "connected"
            ConnectionStatus.LEVEL_NOTCONNECTED -> "disconnected"
            ConnectionStatus.LEVEL_AUTH_FAILED -> "error"
            else -> "connecting"
        }
        if (s == "connected" || s == "disconnected" || s == "error") launching = false
        listener?.invoke(s, if (s == "error") (logmessage ?: "Authentication failed") else "")
    }

    override fun setConnectedVPN(uuid: String?) {}
}
