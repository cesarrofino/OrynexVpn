package com.orynex.vpn

import android.app.Activity

object Engines {
    fun create(): VpnEngine = object : VpnEngine {
        override val available = false
        override fun setListener(l: ((String, String) -> Unit)?) {}
        override fun start(activity: Activity, config: String, name: String) {}
        override fun stop(activity: Activity) {}
    }
}
