plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// OpenVPN engine (country list / VPN Gate). The CI turns it on with withOvpn=true
// only if it compiles; otherwise the app is built with WireGuard only.
val withOvpn = (findProperty("withOvpn") as String?) == "true"

android {
    namespace = "com.orynex.vpn"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.orynex.vpn"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    sourceSets {
        getByName("main").java.srcDir(if (withOvpn) "src/ovpn/kotlin" else "src/stub/kotlin")
    }
    packaging { jniLibs { useLegacyPackaging = true } }
    val ksPath: String? = System.getenv("ORYNEX_KEYSTORE_PATH")
    signingConfigs {
        if (ksPath != null) {
            create("orynex") {
                storeFile = file(ksPath)
                storePassword = System.getenv("ORYNEX_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ORYNEX_KEY_ALIAS")
                keyPassword = System.getenv("ORYNEX_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (ksPath != null) signingConfigs.getByName("orynex")
                            else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.wireguard.android:tunnel:1.0.20230706")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
    if (withOvpn) implementation("com.github.nizwar:openvpn_library:master-SNAPSHOT")
}
