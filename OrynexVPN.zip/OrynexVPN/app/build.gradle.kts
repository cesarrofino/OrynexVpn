plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.orynex.vpn"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.orynex.vpn"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    val ksPath: String? = System.getenv("ORYNEX_KEYSTORE_PATH")
    signingConfigs {
        if (ksPath != null) {
            create("orynex") {
                storeFile = file(ksPath)
                storePassword = System.getenv("ORYNEX_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ORYNEX_KEY_ALIAS")
                keyPassword = System.getenv("ORYNEX_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (ksPath != null) signingConfigs.getByName("orynex")
                            else signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("com.wireguard.android:tunnel:1.0.20230706")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
}
