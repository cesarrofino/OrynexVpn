# Orynex VPN
Kotlin (WebView host + WireGuard tunnel) + plain JavaScript UI.

## Build the APK on GitHub
1. Create a repo and upload all files (keep `.github/workflows/build.yml`).
2. Open the Actions tab, run "Build APK" (or just push).
3. Download the `OrynexVPN-apk` artifact.

## Using it
Open the app > Servers > Add server, then paste a WireGuard config (.conf) from your own server or provider.
