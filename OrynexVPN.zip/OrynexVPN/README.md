# OrynexVPN

Android VPN client with public VPN Gate OpenVPN relays and WireGuard support.

## Mozambique operator profile presets
The app includes selectable profile presets for Vodacom, Movitel and Tmcel, each exposing UDP 48–53 as requested profile labels. These presets do **not** rewrite remote server ports or bypass carrier billing/access controls. They connect through available VPN Gate relays using the UDP transport and the exact endpoint/port published by each volunteer server. A preset label is not proof that a carrier permits that port. Actual compatibility must be tested on a SIM/network from that operator.

VPN Gate servers are volunteer-operated, may disappear at any time, and may have their own logging policies. Review the VPN Gate terms and each relay's policy before use. See https://www.vpngate.net/en/about_faq.aspx.

## Build
Open the project in Android Studio or use Gradle. The real OpenVPN engine is included by default. Use `-PwithOvpn=false` only when intentionally producing a WireGuard-only build. The VPN Gate directory reports country-level locations; Paris and Amsterdam entries use France and Netherlands servers respectively, and the provider does not guarantee the relay is physically in those cities.
